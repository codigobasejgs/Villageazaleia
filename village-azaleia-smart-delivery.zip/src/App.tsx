/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { PackageItem, ActivityLog, AppRole, Unit, PushNotification, MultichannelDispatchReport } from './types';
import { ALL_UNITS, INITIAL_PACKAGES, INITIAL_LOGS } from './data/mockData';
import { RoleSwitcher } from './components/RoleSwitcher';
import { PortariaView } from './components/PortariaView';
import { MoradorView } from './components/MoradorView';
import { TotemView } from './components/TotemView';
import { SindicoDashboard } from './components/SindicoDashboard';
import { PushNotificationBanner } from './components/PushNotificationBanner';
import { multichannelService } from './services/notifications/multichannel.service';
import { sound } from './utils/audio';
import { CheckCircle2, Info, AlertTriangle, X } from 'lucide-react';

interface ToastItem {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning';
}

export default function App() {
  // 1. Role State
  const [currentRole, setCurrentRole] = useState<AppRole>(() => {
    const saved = localStorage.getItem('village_azaleia_role');
    return (saved as AppRole) || 'portaria';
  });

  // 2. Units state with localStorage persistence (360 units with up to 5 contact phones each)
  const [units, setUnits] = useState<Unit[]>(() => {
    try {
      const saved = localStorage.getItem('village_azaleia_units');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return ALL_UNITS;
  });

  // 3. Active Morador simulated unit ID
  const [activeMoradorUnitId, setActiveMoradorUnitId] = useState<string>(() => {
    return 'B03-A102'; // Beatriz Lima
  });

  // 4. Sound state
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('village_azaleia_sound');
    return saved !== null ? saved === 'true' : true;
  });

  // 5. Packages state with localStorage persistence
  const [packages, setPackages] = useState<PackageItem[]>(() => {
    try {
      const saved = localStorage.getItem('village_azaleia_packages');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return INITIAL_PACKAGES;
  });

  // 6. Activity logs state with localStorage persistence
  const [logs, setLogs] = useState<ActivityLog[]>(() => {
    try {
      const saved = localStorage.getItem('village_azaleia_logs');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return INITIAL_LOGS;
  });

  // 7. Multichannel Dispatch Reports
  const [multichannelReports, setMultichannelReports] = useState<MultichannelDispatchReport[]>(() => {
    try {
      const saved = localStorage.getItem('village_azaleia_multichannel_reports');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return [];
  });

  // 8. Push notifications state
  const [pushNotifications, setPushNotifications] = useState<PushNotification[]>(() => {
    try {
      const saved = localStorage.getItem('village_azaleia_push_notifications');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return [
      {
        id: 'notif-initial-1',
        title: 'Nova encomenda recebida para sua unidade!',
        body: 'Morador(a) Beatriz Lima, seu pacote da Amazon (AMZ-BR-49201948) foi guardado na Estante A1. Apresente seu QR Code na Portaria.',
        packageId: 'pkg-1',
        block: 3,
        apartment: 102,
        residentName: 'Beatriz Lima',
        carrier: 'Amazon',
        trackingCode: 'AMZ-BR-49201948',
        shelfString: 'A1',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        read: false
      }
    ];
  });

  const [activePushPopup, setActivePushPopup] = useState<PushNotification | null>(null);

  // 9. Toast notifications state
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Sync sound engine
  useEffect(() => {
    sound.setEnabled(soundEnabled);
    localStorage.setItem('village_azaleia_sound', String(soundEnabled));
  }, [soundEnabled]);

  // Sync role to localStorage
  useEffect(() => {
    localStorage.setItem('village_azaleia_role', currentRole);
  }, [currentRole]);

  // Sync units to localStorage
  useEffect(() => {
    localStorage.setItem('village_azaleia_units', JSON.stringify(units));
  }, [units]);

  // Sync packages to localStorage
  useEffect(() => {
    localStorage.setItem('village_azaleia_packages', JSON.stringify(packages));
  }, [packages]);

  // Sync logs to localStorage
  useEffect(() => {
    localStorage.setItem('village_azaleia_logs', JSON.stringify(logs));
  }, [logs]);

  // Sync multichannel reports to localStorage
  useEffect(() => {
    localStorage.setItem('village_azaleia_multichannel_reports', JSON.stringify(multichannelReports));
  }, [multichannelReports]);

  // Sync push notifications to localStorage
  useEffect(() => {
    localStorage.setItem('village_azaleia_push_notifications', JSON.stringify(pushNotifications));
  }, [pushNotifications]);

  // Show Toast helper
  const showToast = (message: string, type: 'success' | 'info' | 'warning' = 'info') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 6);
    setToasts((prev) => [...prev, { id, message, type }]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Trigger push notification dispatch
  const triggerPushNotification = (pkg: PackageItem) => {
    const newNotif: PushNotification = {
      id: `push-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title: 'Nova encomenda recebida para sua unidade!',
      body: `Morador(a) ${pkg.residentName}, sua encomenda da ${pkg.carrier} (${pkg.trackingCode}) foi registrada e guardada na Estante ${pkg.shelf.shelf}${pkg.shelf.level}.`,
      packageId: pkg.id,
      block: pkg.block,
      apartment: pkg.apartment,
      residentName: pkg.residentName,
      carrier: pkg.carrier,
      trackingCode: pkg.trackingCode,
      shelfString: `${pkg.shelf.shelf}${pkg.shelf.level}`,
      timestamp: new Date().toISOString(),
      read: false
    };

    setPushNotifications((prev) => [newNotif, ...prev]);
    setActivePushPopup(newNotif);
    sound.playNotification();
  };

  // Add new package (Portaria or Totem) & Trigger Multichannel Notifications
  const handleAddPackage = async (
    pkgData: Omit<PackageItem, 'id' | 'status' | 'receivedAt' | 'qrToken' | 'registeredVia'> & {
      registeredVia?: 'PORTARIA' | 'TOTEM_ENTREGADOR';
      deliveryGuyName?: string;
    }
  ) => {
    const newId = `pkg-${Date.now()}`;
    const qrToken = `QR-B${String(pkgData.block).padStart(2, '0')}A${pkgData.apartment}-${newId.slice(-6).toUpperCase()}`;

    const newPackage: PackageItem = {
      ...pkgData,
      id: newId,
      status: 'ARMAZENADA',
      receivedAt: new Date().toISOString(),
      qrToken,
      registeredVia: pkgData.registeredVia || 'PORTARIA'
    };

    setPackages((prev) => [newPackage, ...prev]);

    // Create log entry for physical package entry
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      packageId: newId,
      trackingCode: newPackage.trackingCode,
      unitString: `Bloco ${newPackage.block} - Apt ${newPackage.apartment}`,
      action: pkgData.registeredVia === 'TOTEM_ENTREGADOR' ? 'TOTEM_REGISTRO' : 'ENTRADA',
      description: `Encomenda ${newPackage.carrier} registrada e armazenada na Estante ${newPackage.shelf.shelf}${newPackage.shelf.level}`,
      operator: newPackage.operatorName || 'Portaria Central'
    };

    setLogs((prev) => [newLog, ...prev]);

    // Push Notification Banner UI
    triggerPushNotification(newPackage);

    // Target Unit lookup for Multichannel dispatch (WhatsApp + Resend + Web Push)
    const targetUnit =
      units.find((u) => u.block === newPackage.block && u.apartment === newPackage.apartment) || {
        id: `B${String(newPackage.block).padStart(2, '0')}-A${newPackage.apartment}`,
        block: newPackage.block,
        apartment: newPackage.apartment,
        residentName: newPackage.residentName,
        residentPhone: '(11) 98765-4321',
        residentPhones: [
          { id: 'p1', label: 'Titular', number: '(11) 98765-4321', isWhatsapp: true }
        ],
        residentEmail: `${newPackage.residentName.toLowerCase().replace(/\s+/g, '.')}@email.com`
      };

    try {
      // Execute Multichannel Dispatch across Evolution API, Resend and Web Push
      const report = await multichannelService.dispatchAll(newPackage, targetUnit);
      setMultichannelReports((prev) => [report, ...prev]);

      // Add Multichannel Audit Log
      const multichannelLog: ActivityLog = {
        id: `log-notif-${Date.now()}`,
        timestamp: new Date().toISOString(),
        packageId: newId,
        trackingCode: newPackage.trackingCode,
        unitString: `Bloco ${newPackage.block} - Apt ${newPackage.apartment}`,
        action: 'NOTIFICACAO_MULTICANAL',
        description: `Disparo Multicanal: ${report.whatsappDispatches.length} WhatsApp(s), E-mail Resend e Web Push`,
        operator: 'Sistema Multicanal Village Azaleia'
      };

      setLogs((prev) => [multichannelLog, ...prev]);
    } catch (err) {
      console.warn('[Multichannel Dispatch Error]', err);
    }
  };

  // Test Push trigger for any unit
  const handleTriggerTestPush = (unit: Unit) => {
    const carriers = ['Mercado Livre', 'Amazon', 'Correios', 'Shopee', 'Loggi'] as const;
    const carrier = carriers[Math.floor(Math.random() * carriers.length)];
    const trackingCode = `TEST-${Math.floor(100000 + Math.random() * 900000)}`;

    const simulatedPackage: PackageItem = {
      id: `pkg-test-${Date.now()}`,
      trackingCode,
      unitId: unit.id,
      block: unit.block,
      apartment: unit.apartment,
      residentName: unit.residentName,
      carrier,
      shelf: { shelf: 'A', level: 1 },
      photoUrl: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=400&q=80',
      status: 'ARMAZENADA',
      receivedAt: new Date().toISOString(),
      qrToken: `QR-B${String(unit.block).padStart(2, '0')}A${unit.apartment}-TEST`,
      registeredVia: 'PORTARIA'
    };

    triggerPushNotification(simulatedPackage);
    showToast(`Push disparado para Bloco ${unit.block} Apt ${unit.apartment} (${unit.residentName})!`, 'success');
  };

  // Pickup / Checkout package with digital signature, handover photo, and multichannel receipt dispatch
  const handlePickupPackage = async (
    pkgId: string,
    pickedUpBy: string,
    operatorName: string,
    signatureUrl?: string | null,
    handoverPhotoUrl?: string | null,
    receiptProtocol?: string
  ) => {
    const now = new Date().toISOString();
    const targetPkg = packages.find((p) => p.id === pkgId);
    if (!targetPkg) return;

    const protocol = receiptProtocol || `REC-VA-${Date.now().toString().slice(-8)}`;

    const updatedPackage: PackageItem = {
      ...targetPkg,
      status: 'RETIRADA',
      pickedUpAt: now,
      pickedUpBy: pickedUpBy || targetPkg.residentName,
      operatorName: operatorName || targetPkg.operatorName,
      signatureUrl: signatureUrl || undefined,
      handoverPhotoUrl: handoverPhotoUrl || undefined,
      receiptProtocol: protocol
    };

    setPackages((prev) =>
      prev.map((p) => (p.id === pkgId ? updatedPackage : p))
    );

    // Audit Log 1: RETIRADA
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: now,
      packageId: pkgId,
      trackingCode: targetPkg.trackingCode,
      unitString: `Bloco ${targetPkg.block} - Apt ${targetPkg.apartment}`,
      action: 'RETIRADA',
      description: `Baixa confirmada para ${pickedUpBy || targetPkg.residentName} com Assinatura Digital e Foto`,
      operator: operatorName || 'Portaria Central'
    };

    // Audit Log 2: RECIBO_EMITIDO
    const receiptLog: ActivityLog = {
      id: `log-rec-${Date.now()}`,
      timestamp: now,
      packageId: pkgId,
      trackingCode: targetPkg.trackingCode,
      unitString: `Bloco ${targetPkg.block} - Apt ${targetPkg.apartment}`,
      action: 'RECIBO_EMITIDO',
      description: `Recibo Digital emitido sob protocolo ${protocol}`,
      operator: 'Sistema de Protocolo Digital'
    };

    setLogs((prev) => [receiptLog, newLog, ...prev]);

    // Confetti celebration on delivery
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch {
      // Ignore
    }

    // Lookup unit to dispatch delivery receipt via WhatsApp and Email
    const targetUnit =
      units.find((u) => u.block === targetPkg.block && u.apartment === targetPkg.apartment) || {
        id: `B${String(targetPkg.block).padStart(2, '0')}-A${targetPkg.apartment}`,
        block: targetPkg.block,
        apartment: targetPkg.apartment,
        residentName: targetPkg.residentName,
        residentPhone: '(11) 98765-4321',
        residentPhones: [
          { id: 'p1', label: 'Titular', number: '(11) 98765-4321', isWhatsapp: true }
        ],
        residentEmail: `${targetPkg.residentName.toLowerCase().replace(/\s+/g, '.')}@email.com`
      };

    try {
      const receiptReport = await multichannelService.dispatchDeliveryReceipt(updatedPackage, targetUnit);
      setMultichannelReports((prev) => [receiptReport, ...prev]);
    } catch (e) {
      console.warn('[Receipt dispatch error]', e);
    }
  };

  // Update a unit profile (resident name, phones up to 5, email)
  const handleUpdateUnit = (updatedUnit: Unit) => {
    setUnits((prev) =>
      prev.map((u) => (u.id === updatedUnit.id || (u.block === updatedUnit.block && u.apartment === updatedUnit.apartment) ? updatedUnit : u))
    );
    setActiveMoradorUnitId(updatedUnit.id);
  };

  // Open Resident view from Push Notification Banner
  const handleOpenResidentAppFromPush = (notification: PushNotification) => {
    const targetUnit = units.find(
      (u) => u.block === notification.block && u.apartment === notification.apartment
    );

    if (targetUnit) {
      setActiveMoradorUnitId(targetUnit.id);
    }
    setCurrentRole('morador');
    setActivePushPopup(null);
    showToast(`Visão do Morador aberta para Bloco ${notification.block} - Apt ${notification.apartment}!`, 'success');
  };

  // Reset to initial mock data
  const handleResetData = () => {
    setUnits(ALL_UNITS);
    setPackages(INITIAL_PACKAGES);
    setLogs(INITIAL_LOGS);
    setMultichannelReports([]);
    localStorage.removeItem('village_azaleia_units');
    localStorage.removeItem('village_azaleia_packages');
    localStorage.removeItem('village_azaleia_logs');
    localStorage.removeItem('village_azaleia_multichannel_reports');
    localStorage.removeItem('village_azaleia_push_notifications');
    showToast('Dados, unidades e encomendas restaurados para o padrão de demonstração!', 'success');
  };

  const pendingCount = packages.filter((p) => p.status !== 'RETIRADA').length;

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A2E22] flex flex-col font-sans antialiased selection:bg-[#D81B60] selection:text-white">
      {/* 1. Global Push Notification Banner (Visible across ALL tabs & views) */}
      <PushNotificationBanner
        notification={activePushPopup}
        onDismiss={() => setActivePushPopup(null)}
        onOpenResidentApp={handleOpenResidentAppFromPush}
      />

      {/* 2. Persistent Role Switcher Bar */}
      <RoleSwitcher
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        pendingCount={pendingCount}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
        onResetData={handleResetData}
      />

      {/* 3. Main Content Area according to selected profile */}
      <main className="flex-1 pb-16">
        {currentRole === 'portaria' && (
          <PortariaView
            packages={packages}
            units={units}
            onAddPackage={handleAddPackage}
            onPickupPackage={handlePickupPackage}
            onShowToast={showToast}
          />
        )}

        {currentRole === 'morador' && (
          <MoradorView
            packages={packages}
            units={units}
            activeUnitId={activeMoradorUnitId}
            onSelectUnit={setActiveMoradorUnitId}
            onUpdateUnit={handleUpdateUnit}
            notifications={pushNotifications}
            multichannelReports={multichannelReports}
            onTriggerTestPush={handleTriggerTestPush}
            onShowToast={showToast}
          />
        )}

        {currentRole === 'totem' && (
          <TotemView
            units={units}
            packages={packages}
            onAddPackage={handleAddPackage}
            onShowToast={showToast}
          />
        )}

        {currentRole === 'sindico' && (
          <SindicoDashboard
            packages={packages}
            logs={logs}
            units={units}
            onShowToast={showToast}
          />
        )}
      </main>

      {/* Toast Notification Container with Azaleia Branding */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto p-4 rounded-2xl shadow-xl border backdrop-blur-md flex items-start justify-between gap-3 text-xs sm:text-sm animate-in slide-in-from-bottom-5 transition-all ${
              toast.type === 'success'
                ? 'bg-[#0D3823]/95 border-[#D4AF37]/50 text-white shadow-emerald-950/30'
                : toast.type === 'warning'
                ? 'bg-[#880E4F]/95 border-[#FFF2B2]/50 text-pink-50 shadow-pink-950/30'
                : 'bg-[#061D12]/95 border-[#D4AF37]/40 text-emerald-100 shadow-black/40'
            }`}
          >
            <div className="flex items-start gap-2.5">
              {toast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />}
              {toast.type === 'warning' && <AlertTriangle className="w-5 h-5 text-[#FF80AB] shrink-0 mt-0.5" />}
              {toast.type === 'info' && <Info className="w-5 h-5 text-[#FFF2B2] shrink-0 mt-0.5" />}
              <span className="font-medium leading-snug">{toast.message}</span>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="text-white/60 hover:text-white p-0.5 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { PackageItem, Unit, Carrier } from '../types';
import { CARRIER_CONFIG, SAMPLE_PACKAGE_PHOTOS, getSmartShelfSuggestion } from '../data/mockData';
import {
  Box,
  QrCode,
  Camera,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Building,
  RotateCcw,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Printer,
  Barcode
} from 'lucide-react';
import { sound } from '../utils/audio';
import { BarcodeDisplay } from './VisualCodes';
import { VillageAzaleiaLogo } from './VillageAzaleiaLogo';

interface TotemViewProps {
  units: Unit[];
  packages: PackageItem[];
  onAddPackage: (pkg: Omit<PackageItem, 'id' | 'status' | 'receivedAt' | 'qrToken' | 'registeredVia'> & { deliveryGuyName?: string; registeredVia?: 'TOTEM_ENTREGADOR' }) => void;
  onShowToast: (message: string, type?: 'success' | 'info' | 'warning') => void;
}

export const TotemView: React.FC<TotemViewProps> = ({
  units,
  packages,
  onAddPackage,
  onShowToast
}) => {
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);

  // STEP 1 STATE
  const [carrier, setCarrier] = useState<Carrier>('Mercado Livre');
  const [trackingCode, setTrackingCode] = useState('');
  const [deliveryGuyName, setDeliveryGuyName] = useState('');

  // STEP 2 STATE
  const [selectedBlock, setSelectedBlock] = useState<number>(1);
  const [selectedApartment, setSelectedApartment] = useState<number>(101);

  // STEP 3 STATE
  const [selectedPhoto, setSelectedPhoto] = useState<string>(SAMPLE_PACKAGE_PHOTOS[1]);
  const [isPhotoCaptured, setIsPhotoCaptured] = useState(false);

  // STEP 4 / FINAL CONFIRMATION STATE
  const [createdProtocol, setCreatedProtocol] = useState<string | null>(null);

  // Matched unit
  const targetUnit = units.find(u => u.block === selectedBlock && u.apartment === selectedApartment) || units[0];

  const handleNextStep = () => {
    if (currentStep === 1) {
      if (!trackingCode.trim()) {
        const gen = `${carrier.slice(0, 3).toUpperCase()}-${Math.floor(10000000 + Math.random() * 90000000)}`;
        setTrackingCode(gen);
      }
      sound.playScanBeep();
      setCurrentStep(2);
    } else if (currentStep === 2) {
      sound.playScanBeep();
      setCurrentStep(3);
    } else if (currentStep === 3) {
      sound.playScanBeep();
      setCurrentStep(4);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      sound.playScanBeep();
      setCurrentStep((currentStep - 1) as 1 | 2 | 3 | 4);
    }
  };

  const handleConfirmTotemDeposit = () => {
    const sug = getSmartShelfSuggestion(packages);
    const finalTracking = trackingCode.trim() || `TOTEM-${Date.now().toString().slice(-6)}`;
    const protocolNumber = `PROT-VA-${Math.floor(100000 + Math.random() * 900000)}`;

    onAddPackage({
      trackingCode: finalTracking,
      unitId: targetUnit.id,
      block: targetUnit.block,
      apartment: targetUnit.apartment,
      residentName: targetUnit.residentName,
      carrier: carrier,
      shelf: { shelf: sug.shelf, level: sug.level },
      photoUrl: selectedPhoto,
      notes: `Depósito realizado via Totem de Autoatendimento. Entregador: ${deliveryGuyName || 'Não informado'}`,
      registeredVia: 'TOTEM_ENTREGADOR',
      deliveryGuyName: deliveryGuyName || 'Entregador Parceiro',
      operatorName: 'Totem Central de Autoatendimento'
    });

    setCreatedProtocol(protocolNumber);
    sound.playCheckout();
    onShowToast(`Depósito registrado no Totem! Notificação enviada para o Bloco ${targetUnit.block} Apt ${targetUnit.apartment}.`, 'success');
  };

  const handleResetTotem = () => {
    sound.playScanBeep();
    setCurrentStep(1);
    setTrackingCode('');
    setDeliveryGuyName('');
    setSelectedBlock(1);
    setSelectedApartment(101);
    setCreatedProtocol(null);
    setIsPhotoCaptured(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6 text-[#1A2E22]">
      {/* Totem Header Banner with Azaleia Branding */}
      <div className="bg-gradient-to-r from-[#061D12] via-[#0D3823] to-[#15462D] rounded-3xl border border-[#D4AF37]/50 p-6 shadow-2xl flex items-center justify-between text-white relative overflow-hidden">
        <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-[#D81B60]/15 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center gap-4 relative z-10">
          <div className="p-3.5 bg-white/10 backdrop-blur-md rounded-2xl border border-[#D4AF37]/40 shadow-inner flex items-center justify-center">
            <VillageAzaleiaLogo variant="icon" size="md" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-[#D81B60]/30 text-[#FFF2B2] font-bold border border-[#D81B60]/50 uppercase tracking-wider">
                Totem de Autoatendimento
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />
              <span className="text-[11px] text-white/80">Recepção de Cargas</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight font-brand">
              Residencial Village Azaleia
            </h2>
            <p className="text-xs text-white/80 font-medium">
              Totem Inteligente de Entrada Rápida de Encomendas
            </p>
          </div>
        </div>

        <button
          onClick={handleResetTotem}
          title="Reiniciar Totem"
          className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all border border-white/20 flex items-center gap-1.5 text-xs font-extrabold shadow-sm"
        >
          <RotateCcw className="w-4 h-4 text-[#FFF2B2]" />
          <span className="hidden sm:inline">Nova Entrada</span>
        </button>
      </div>

      {/* Progress Step Bar */}
      {!createdProtocol && (
        <div className="grid grid-cols-4 gap-2 sm:gap-4">
          {[
            { step: 1, label: '1. Rastreio & Carga' },
            { step: 2, label: '2. Destino (Apt)' },
            { step: 3, label: '3. Foto Pacote' },
            { step: 4, label: '4. Confirmação' }
          ].map((s) => {
            const isCompleted = currentStep > s.step;
            const isCurrent = currentStep === s.step;
            return (
              <div
                key={s.step}
                className={`p-3 rounded-2xl border text-center transition-all ${
                  isCurrent
                    ? 'bg-gradient-to-r from-[#D81B60] to-[#AD1457] border-[#D81B60] text-white font-extrabold shadow-md ring-2 ring-[#D81B60]/30'
                    : isCompleted
                    ? 'bg-[#E8F5E9] border-[#A5D6A7] text-[#0D3823] font-bold'
                    : 'bg-white border-slate-200 text-slate-400 font-medium shadow-sm'
                }`}
              >
                <div className="text-xs sm:text-sm">{s.label}</div>
              </div>
            );
          })}
        </div>
      )}

      {/* STEP CONTAINER */}
      <div className="bg-white rounded-3xl border border-[#D4AF37]/35 p-6 sm:p-8 shadow-xl space-y-6">
        {/* STEP 1: CÓDIGO E TRANSPORTADORA */}
        {currentStep === 1 && !createdProtocol && (
          <div className="space-y-6">
            <div>
              <span className="font-brand font-bold text-xs tracking-wider text-[#D81B60] uppercase">Passo 1 de 4</span>
              <h3 className="text-xl font-black text-[#0D3823]">Identifique a Encomenda</h3>
              <p className="text-xs text-slate-500 font-medium">Selecione a transportadora e digite ou escaneie o código</p>
            </div>

            {/* Carrier selection large buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {(['Mercado Livre', 'Amazon', 'Correios', 'Shopee', 'Loggi', 'Outra'] as Carrier[]).map((c) => {
                const cfg = CARRIER_CONFIG[c];
                const isSel = carrier === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      setCarrier(c);
                      sound.playScanBeep();
                    }}
                    className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 text-sm font-extrabold ${
                      isSel
                        ? 'bg-[#FCE4EC] border-[#D81B60] text-[#AD1457] ring-2 ring-[#D81B60]/30 shadow-md scale-[1.02]'
                        : 'bg-[#F8F9FA] border-slate-200 text-[#0D3823] hover:bg-slate-100 hover:border-slate-300'
                    }`}
                  >
                    <span className="text-3xl">{cfg.icon}</span>
                    <span>{c}</span>
                  </button>
                );
              })}
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-extrabold text-[#0D3823] uppercase">
                Código de Rastreio / Etiqueta:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={trackingCode}
                  onChange={(e) => setTrackingCode(e.target.value)}
                  placeholder="Ex: ML-892348123 ou aponte ao scanner"
                  className="flex-1 bg-[#F8F9FA] border border-slate-300 rounded-2xl px-4 py-3.5 text-base text-[#0D3823] placeholder-slate-400 focus:outline-none focus:border-[#D81B60] focus:ring-2 focus:ring-[#D81B60]/20 font-mono font-bold shadow-inner"
                />
                <button
                  type="button"
                  onClick={() => {
                    const code = `${carrier.slice(0, 3).toUpperCase()}-${Math.floor(100000000 + Math.random() * 900000000)}`;
                    setTrackingCode(code);
                    sound.playScanBeep();
                  }}
                  className="px-4 py-3 rounded-2xl bg-[#0D3823] hover:bg-[#15462D] text-white font-extrabold text-xs shrink-0 shadow transition-all border border-[#D4AF37]/30"
                >
                  Gerar Rastreio
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-extrabold text-[#0D3823] uppercase">
                Nome do Entregador (Opcional):
              </label>
              <input
                type="text"
                value={deliveryGuyName}
                onChange={(e) => setDeliveryGuyName(e.target.value)}
                placeholder="Ex: Lucas Motoboy / Entregador Shopee"
                className="w-full bg-[#F8F9FA] border border-slate-300 rounded-2xl px-4 py-3 text-sm text-[#0D3823] font-semibold focus:outline-none focus:border-[#D81B60] focus:ring-2 focus:ring-[#D81B60]/20 shadow-inner"
              />
            </div>

            <button
              onClick={handleNextStep}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#D81B60] via-[#AD1457] to-[#880E4F] hover:from-[#AD1457] hover:to-[#730941] text-white font-black text-base shadow-xl shadow-[#D81B60]/25 transition-all flex items-center justify-center gap-2"
            >
              <span>Avançar para Escolha da Unidade</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* STEP 2: ESCOLHER UNIDADE */}
        {currentStep === 2 && !createdProtocol && (
          <div className="space-y-6">
            <div>
              <span className="font-brand font-bold text-xs tracking-wider text-[#D81B60] uppercase">Passo 2 de 4</span>
              <h3 className="text-xl font-black text-[#0D3823]">Qual a Unidade de Destino?</h3>
              <p className="text-xs text-slate-500 font-medium">Selecione o Bloco e o Apartamento no teclado touch</p>
            </div>

            {/* Block selector */}
            <div className="space-y-2">
              <label className="block text-xs font-extrabold text-[#0D3823] uppercase">Selecione o Bloco (1 a 12):</label>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                {Array.from({ length: 12 }, (_, i) => i + 1).map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => {
                      setSelectedBlock(b);
                      sound.playScanBeep();
                    }}
                    className={`py-3 rounded-xl border text-sm font-extrabold transition-all ${
                      selectedBlock === b
                        ? 'bg-gradient-to-r from-[#D81B60] to-[#AD1457] border-[#D81B60] text-white shadow-md'
                        : 'bg-[#F8F9FA] border-slate-300 text-[#0D3823] hover:bg-slate-100'
                    }`}
                  >
                    Bloco {b}
                  </button>
                ))}
              </div>
            </div>

            {/* Apartment quick selector */}
            <div className="space-y-2">
              <label className="block text-xs font-extrabold text-[#0D3823] uppercase">Selecione o Apartamento:</label>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 max-h-48 overflow-y-auto pr-1">
                {[101, 102, 103, 104, 201, 202, 203, 204, 301, 302, 303, 304, 401, 402, 403, 404, 501, 502, 503, 504, 601, 602, 603, 604, 701, 702, 703, 704, 801, 802].map((apt) => (
                  <button
                    key={apt}
                    type="button"
                    onClick={() => {
                      setSelectedApartment(apt);
                      sound.playScanBeep();
                    }}
                    className={`py-2.5 rounded-xl border text-xs font-extrabold transition-all ${
                      selectedApartment === apt
                        ? 'bg-[#0D3823] border-[#0D3823] text-white shadow-md'
                        : 'bg-[#F8F9FA] border-slate-300 text-[#0D3823] hover:bg-slate-100'
                    }`}
                  >
                    Apt {apt}
                  </button>
                ))}
              </div>
            </div>

            {/* Confirmed resident card */}
            <div className="p-4 rounded-2xl bg-[#E8F5E9] border border-[#A5D6A7] flex items-center justify-between">
              <div>
                <span className="text-[11px] font-extrabold text-[#0D3823] uppercase">Unidade Localizada:</span>
                <div className="text-base font-black text-[#0D3823]">
                  Bloco {selectedBlock} — Apartamento {selectedApartment}
                </div>
                <div className="text-xs text-slate-600 font-semibold">Morador: {targetUnit.residentName}</div>
              </div>
              <span className="px-3 py-1 rounded-full bg-[#0D3823] text-white text-xs font-extrabold shadow-sm">
                Confirmado
              </span>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handlePreviousStep}
                className="px-6 py-3.5 rounded-2xl bg-[#F8F9FA] hover:bg-slate-200 text-[#0D3823] font-extrabold text-sm border border-slate-300"
              >
                Voltar
              </button>
              <button
                onClick={handleNextStep}
                className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-[#D81B60] to-[#AD1457] hover:from-[#AD1457] hover:to-[#880E4F] text-white font-black text-base shadow-xl flex items-center justify-center gap-2"
              >
                <span>Avançar para Foto do Pacote</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: FOTOGRAFAR ENCOMENDA */}
        {currentStep === 3 && !createdProtocol && (
          <div className="space-y-6">
            <div>
              <span className="font-brand font-bold text-xs tracking-wider text-[#D81B60] uppercase">Passo 3 de 4</span>
              <h3 className="text-xl font-black text-[#0D3823]">Fotografe a Encomenda na Bandeja</h3>
              <p className="text-xs text-slate-500 font-medium">Posicione o pacote sob a câmera do totem para registro visual</p>
            </div>

            <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-[#061D12] border border-[#D4AF37]/40 space-y-4 shadow-inner">
              <div className="relative w-full max-w-sm h-52 rounded-2xl overflow-hidden border-2 border-[#D4AF37] shadow-xl">
                <img
                  src={selectedPhoto}
                  alt="Camera Totem"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#061D12]/85 backdrop-blur-sm text-[11px] font-bold text-[#FFF2B2] flex items-center gap-1.5 border border-[#D4AF37]/40">
                  <span className="w-2 h-2 rounded-full bg-[#D81B60] animate-pulse" />
                  <span>Câmera Totem Ativa</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className="text-xs text-white/80 font-medium">Trocar foto simulada:</span>
                {SAMPLE_PACKAGE_PHOTOS.map((p, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setSelectedPhoto(p);
                      sound.playScanBeep();
                    }}
                    className={`w-9 h-9 rounded-lg border overflow-hidden transition-transform ${
                      selectedPhoto === p ? 'border-[#D4AF37] ring-2 ring-[#D4AF37] scale-110' : 'border-white/30 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={p} alt={`sample ${i}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handlePreviousStep}
                className="px-6 py-3.5 rounded-2xl bg-[#F8F9FA] hover:bg-slate-200 text-[#0D3823] font-extrabold text-sm border border-slate-300"
              >
                Voltar
              </button>
              <button
                onClick={handleNextStep}
                className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-[#D81B60] to-[#AD1457] hover:from-[#AD1457] hover:to-[#880E4F] text-white font-black text-base shadow-xl flex items-center justify-center gap-2"
              >
                <span>Revisar e Finalizar Depósito</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: REVISÃO & CONFIRMAR DEPÓSITO */}
        {currentStep === 4 && !createdProtocol && (
          <div className="space-y-6">
            <div>
              <span className="font-brand font-bold text-xs tracking-wider text-[#D81B60] uppercase">Passo 4 de 4</span>
              <h3 className="text-xl font-black text-[#0D3823]">Revise as Informações de Depósito</h3>
              <p className="text-xs text-slate-500 font-medium">Verifique se todos os dados estão corretos antes de depositar</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-[#F8F9FA] border border-[#D4AF37]/40 space-y-3">
                <div className="text-xs font-extrabold text-[#0D3823] uppercase">Resumo da Encomenda:</div>
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Transportadora:</span>
                    <span className="font-bold text-[#0D3823]">{carrier}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Rastreio:</span>
                    <span className="font-mono font-bold text-[#0D3823]">{trackingCode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Destino:</span>
                    <span className="font-extrabold text-[#D81B60]">
                      Bloco {selectedBlock} — Apt {selectedApartment}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Morador:</span>
                    <span className="font-bold text-[#0D3823]">{targetUnit.residentName}</span>
                  </div>
                  {deliveryGuyName && (
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-medium">Entregador:</span>
                      <span className="text-[#0D3823] font-semibold">{deliveryGuyName}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="rounded-2xl overflow-hidden border border-slate-300 bg-slate-100 h-36 shadow-inner">
                <img
                  src={selectedPhoto}
                  alt="Foto Revisão"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#E8F5E9] border border-[#A5D6A7] text-xs text-[#0D3823] font-semibold flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-[#0D3823] shrink-0" />
              <span>
                Ao confirmar, a portaria receberá o aviso de entrada e o morador receberá o alerta no aplicativo.
              </span>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handlePreviousStep}
                className="px-6 py-3.5 rounded-2xl bg-[#F8F9FA] hover:bg-slate-200 text-[#0D3823] font-extrabold text-sm border border-slate-300"
              >
                Voltar
              </button>
              <button
                onClick={handleConfirmTotemDeposit}
                className="flex-1 py-4 rounded-2xl bg-gradient-to-r from-[#D81B60] via-[#AD1457] to-[#880E4F] hover:from-[#AD1457] hover:to-[#730941] text-white font-black text-base shadow-xl shadow-[#D81B60]/25 flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-5 h-5 text-[#FFF2B2]" />
                <span>Confirmar Depósito & Imprimir Comprovante</span>
              </button>
            </div>
          </div>
        )}

        {/* RECEIPT AFTER CONFIRMATION */}
        {createdProtocol && (
          <div className="text-center space-y-6 py-4">
            <div className="w-16 h-16 rounded-full bg-[#E8F5E9] text-[#0D3823] border-2 border-[#A5D6A7] flex items-center justify-center mx-auto shadow-lg">
              <CheckCircle2 className="w-9 h-9 text-[#0D3823]" />
            </div>

            <div>
              <span className="font-brand font-bold text-xs tracking-wider text-[#D81B60] uppercase">Depósito Finalizado</span>
              <h3 className="text-2xl font-black text-[#0D3823]">Depósito Realizado com Sucesso!</h3>
              <p className="text-xs text-slate-500 mt-1 font-medium">
                A encomenda foi encaminhada para a triagem da Portaria Central do Village Azaleia.
              </p>
            </div>

            {/* Physical Print Ticket Mockup */}
            <div className="max-w-md mx-auto bg-white text-slate-900 p-6 rounded-2xl shadow-xl text-left space-y-3 font-mono text-xs border-2 border-dashed border-[#D4AF37]">
              <div className="text-center border-b border-dashed border-slate-300 pb-3">
                <div className="flex justify-center mb-1">
                  <VillageAzaleiaLogo variant="badge" size="sm" />
                </div>
                <div className="font-extrabold text-sm text-[#0D3823] font-sans">RESIDENCIAL VILLAGE AZALEIA</div>
                <div className="text-[10px] text-slate-500 font-sans">TOTEM DE AUTOATENDIMENTO DE ENTRADA</div>
              </div>

              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Protocolo:</span>
                  <span className="font-bold text-[#D81B60]">{createdProtocol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Transportadora:</span>
                  <span className="font-bold text-[#0D3823]">{carrier}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Destino:</span>
                  <span className="font-bold text-[#0D3823]">Bloco {selectedBlock} - Apt {selectedApartment}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Morador:</span>
                  <span className="text-[#0D3823] font-medium">{targetUnit.residentName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Rastreio:</span>
                  <span className="font-bold text-[#0D3823]">{trackingCode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Data e Hora:</span>
                  <span className="text-slate-700">{new Date().toLocaleString('pt-BR')}</span>
                </div>
              </div>

              <div className="border-t border-dashed border-slate-300 pt-3 flex justify-center">
                <BarcodeDisplay value={createdProtocol} height={30} />
              </div>
            </div>

            <button
              onClick={handleResetTotem}
              className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-[#D81B60] to-[#AD1457] hover:from-[#AD1457] hover:to-[#880E4F] text-white font-extrabold text-sm shadow-lg inline-flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4 text-[#FFF2B2]" />
              <span>Realizar Nova Entrega</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};


import React, { useState, useMemo, useEffect } from 'react';
import { PackageItem, Unit, Carrier, PushNotification, MultichannelDispatchReport } from '../types';
import { CARRIER_CONFIG } from '../data/mockData';
import { QRCodeDisplay } from './VisualCodes';
import { MoradorRegistrationModal } from './MoradorRegistrationModal';
import { DeliveryReceiptModal } from './DeliveryReceiptModal';
import { webPushService } from '../services/notifications/web-push';
import { multichannelService } from '../services/notifications/multichannel.service';
import {
  Smartphone,
  Download,
  Bell,
  BellRing,
  Package,
  Clock,
  MapPin,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  Building,
  User,
  Share2,
  FileText,
  X,
  Maximize2,
  Check,
  Sparkles,
  Send,
  AlertTriangle,
  Phone,
  Mail,
  MessageSquare,
  Radio,
  ExternalLink,
  Edit3,
  Users
} from 'lucide-react';
import { sound } from '../utils/audio';
import { VillageAzaleiaLogo } from './VillageAzaleiaLogo';

interface MoradorViewProps {
  packages: PackageItem[];
  units: Unit[];
  activeUnitId?: string;
  onSelectUnit?: (unitId: string) => void;
  onUpdateUnit?: (updatedUnit: Unit) => void;
  notifications?: PushNotification[];
  multichannelReports?: MultichannelDispatchReport[];
  onTriggerTestPush?: (unit: Unit) => void;
  onShowToast: (message: string, type?: 'success' | 'info' | 'warning') => void;
}

export const MoradorView: React.FC<MoradorViewProps> = ({
  packages,
  units,
  activeUnitId,
  onSelectUnit,
  onUpdateUnit,
  notifications = [],
  multichannelReports = [],
  onTriggerTestPush,
  onShowToast
}) => {
  // Default unit: Bloco 3, Apt 102 (Beatriz Lima) or first unit with packages
  const defaultUnit = units.find((u) => u.block === 3 && u.apartment === 102) || units[0];
  const [localSelectedUnitId, setLocalSelectedUnitId] = useState<string>(activeUnitId || defaultUnit.id);
  const [isInstalledPwa, setIsInstalledPwa] = useState(false);
  const [pushPermission, setPushPermission] = useState<NotificationPermission>(() => {
    return webPushService.getPermission();
  });
  const [activeScreenTab, setActiveScreenTab] = useState<'disponiveis' | 'historico' | 'notificacoes'>('disponiveis');
  const [fullscreenQrPackage, setFullscreenQrPackage] = useState<PackageItem | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<PackageItem | null>(null);
  const [showNotificationDrawer, setShowNotificationDrawer] = useState(false);
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);
  const [inPhonePushBanner, setInPhonePushBanner] = useState<PushNotification | null>(null);
  const [isTestingMultichannel, setIsTestingMultichannel] = useState(false);
  const [lastDispatchReport, setLastDispatchReport] = useState<MultichannelDispatchReport | null>(null);

  // Sync if activeUnitId changes externally (e.g. from global push notification click)
  useEffect(() => {
    if (activeUnitId) {
      setLocalSelectedUnitId(activeUnitId);
      setActiveScreenTab('disponiveis');
    }
  }, [activeUnitId]);

  // Current unit data
  const currentUnit = useMemo(() => {
    return units.find((u) => u.id === localSelectedUnitId) || defaultUnit;
  }, [units, localSelectedUnitId, defaultUnit]);

  // Check Web Push permission state on load
  useEffect(() => {
    if (webPushService.isSupported()) {
      setPushPermission(webPushService.getPermission());
    }
  }, []);

  // If a new push notification arrived for this unit, show in-phone notch banner
  useEffect(() => {
    if (notifications.length > 0) {
      const latest = notifications[0];
      if (latest.block === currentUnit.block && latest.apartment === currentUnit.apartment) {
        setInPhonePushBanner(latest);
        const timer = setTimeout(() => {
          setInPhonePushBanner(null);
        }, 7000);
        return () => clearTimeout(timer);
      }
    }
  }, [notifications, currentUnit]);

  // Packages for this unit
  const myPackages = useMemo(() => {
    return packages.filter((p) => p.block === currentUnit.block && p.apartment === currentUnit.apartment);
  }, [packages, currentUnit]);

  const availablePackages = useMemo(() => {
    return myPackages.filter((p) => p.status !== 'RETIRADA');
  }, [myPackages]);

  const pickedUpPackages = useMemo(() => {
    return myPackages.filter((p) => p.status === 'RETIRADA');
  }, [myPackages]);

  // Filter push notifications for this unit
  const myNotifications = useMemo(() => {
    return notifications.filter((n) => n.block === currentUnit.block && n.apartment === currentUnit.apartment);
  }, [notifications, currentUnit]);

  // Filter multichannel reports for this unit
  const myReports = useMemo(() => {
    const unitStr = `Bloco ${currentUnit.block} - Apt ${currentUnit.apartment}`;
    return multichannelReports.filter((r) => r.unitString === unitStr);
  }, [multichannelReports, currentUnit]);

  const handleUnitChange = (unitId: string) => {
    setLocalSelectedUnitId(unitId);
    if (onSelectUnit) onSelectUnit(unitId);
    sound.playScanBeep();
  };

  const handleInstallPWA = () => {
    sound.playSuccess();
    setIsInstalledPwa(true);
    onShowToast('Village Azaleia PWA adicionado à Tela de Início!', 'success');
  };

  const handleRequestPushPermission = async () => {
    sound.playScanBeep();
    const perm = await webPushService.requestPermission();
    setPushPermission(perm);
    if (perm === 'granted') {
      onShowToast('Permissão para Web Push Notifications concedida!', 'success');
    } else {
      onShowToast('Permissão de notificações não autorizada no navegador.', 'warning');
    }
  };

  // Test full multichannel dispatch
  const handleTestMultichannel = async () => {
    setIsTestingMultichannel(true);
    sound.playScanBeep();

    const samplePackage: PackageItem = {
      id: `test-pkg-${Date.now()}`,
      trackingCode: `VA-TEST-${Math.floor(100000 + Math.random() * 900000)}`,
      unitId: currentUnit.id,
      block: currentUnit.block,
      apartment: currentUnit.apartment,
      residentName: currentUnit.residentName,
      carrier: 'Mercado Livre',
      shelf: { shelf: 'A', level: 1 },
      photoUrl: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=400&q=80',
      status: 'ARMAZENADA',
      receivedAt: new Date().toISOString(),
      qrToken: `QR-B${String(currentUnit.block).padStart(2, '0')}A${currentUnit.apartment}-TEST`,
      registeredVia: 'PORTARIA'
    };

    try {
      const report = await multichannelService.dispatchAll(samplePackage, currentUnit);
      setLastDispatchReport(report);
      sound.playSuccess();
      onShowToast(
        `Disparo Multicanal concluído para ${report.whatsappDispatches.length} WhatsApp(s), E-mail e Web Push!`,
        'success'
      );
    } catch (err) {
      console.error(err);
      onShowToast('Erro ao testar disparo multicanal.', 'warning');
    } finally {
      setIsTestingMultichannel(false);
    }
  };

  const handleSaveResidentProfile = (updated: Unit) => {
    if (onUpdateUnit) {
      onUpdateUnit(updated);
    }
    setLocalSelectedUnitId(updated.id);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Top Unit Selector Bar & Test Controls */}
      <div className="bg-white rounded-3xl border-2 border-[#D4AF37]/40 p-5 flex flex-col lg:flex-row items-center justify-between gap-4 shadow-xl text-[#1A2E22]">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-[#FCE4EC] text-[#D81B60] border border-[#F48FB1] flex items-center justify-center shadow-md shrink-0">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-brand font-black text-xs tracking-wider text-[#D81B60] uppercase">
                PWA Mobile Morador
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
              <span className="text-xs font-black text-[#0D3823]">Residencial Village Azaleia</span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-[#0D3823]">
              Simulador do Aplicativo com Notificações Multicanal
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              3 Canais: WhatsApp (Evolution API até 5 números), E-mail (Resend) e Web Push nativo
            </p>
          </div>
        </div>

        {/* Change Unit dropdown + Actions */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full lg:w-auto">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-bold whitespace-nowrap">Morador:</span>
            <select
              value={localSelectedUnitId}
              onChange={(e) => handleUnitChange(e.target.value)}
              className="w-full sm:w-64 bg-[#F8F9FA] border border-slate-300 rounded-xl px-3 py-2 text-xs text-[#0D3823] font-bold focus:outline-none focus:border-[#D81B60] focus:ring-2 focus:ring-[#D81B60]/20 shadow-inner"
            >
              {units.map((u) => {
                const count = packages.filter(
                  (p) => p.block === u.block && p.apartment === u.apartment && p.status !== 'RETIRADA'
                ).length;
                const phoneCount = u.residentPhones?.length || 1;
                return (
                  <option key={u.id} value={u.id}>
                    Bloco {u.block} - Apt {u.apartment} ({u.residentName}) [{phoneCount} tel]{count > 0 ? ` [${count} pronta]` : ''}
                  </option>
                );
              })}
            </select>
          </div>

          <button
            onClick={() => setShowRegistrationModal(true)}
            className="px-3.5 py-2 rounded-xl bg-[#0D3823] hover:bg-[#15462D] text-white text-xs font-extrabold shadow-md flex items-center justify-center gap-1.5 transition-all border border-[#D4AF37]/40 active:scale-95 whitespace-nowrap"
            title="Editar cadastro da unidade e telefones de contato"
          >
            <Edit3 className="w-3.5 h-3.5 text-[#FFF2B2]" />
            <span>Editar Cadastro & Telefones ({currentUnit.residentPhones?.length || 1}/5)</span>
          </button>

          <button
            onClick={handleTestMultichannel}
            disabled={isTestingMultichannel}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#D81B60] to-[#AD1457] hover:from-[#AD1457] hover:to-[#880E4F] text-white text-xs font-extrabold shadow-md flex items-center justify-center gap-1.5 transition-all border border-[#FFF2B2]/20 active:scale-95 disabled:opacity-50 whitespace-nowrap"
            title="Dispara teste em tempo real para WhatsApp, E-mail e Web Push"
          >
            <Send className={`w-3.5 h-3.5 text-[#FFF2B2] ${isTestingMultichannel ? 'animate-spin' : ''}`} />
            <span>{isTestingMultichannel ? 'Disparando...' : 'Testar Disparo Multicanal'}</span>
          </button>
        </div>
      </div>

      {/* Multichannel Status Ribbon */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* WhatsApp Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-sm flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center font-bold">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-[#0D3823]">WhatsApp Evolution API</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                {currentUnit.residentPhones?.length || 1} número(s) cadastrado(s) para esta unidade
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
            Ativo
          </span>
        </div>

        {/* Email Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-sm flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FCE4EC] text-[#D81B60] border border-[#F48FB1] flex items-center justify-center font-bold">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-[#0D3823]">E-mail Resend API</span>
                <span className="w-2 h-2 rounded-full bg-[#D81B60]" />
              </div>
              <p className="text-[11px] text-slate-500 font-medium truncate max-w-[180px]">
                {currentUnit.residentEmail || 'morador@email.com'}
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-pink-100 text-pink-800 border border-pink-300">
            HTML Village
          </span>
        </div>

        {/* Web Push Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-sm flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center font-bold">
              <BellRing className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-[#0D3823]">Web Push PWA</span>
                <span
                  className={`w-2 h-2 rounded-full ${
                    pushPermission === 'granted' ? 'bg-emerald-500' : 'bg-amber-400'
                  }`}
                />
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                {pushPermission === 'granted' ? 'Permissão nativa concedida' : 'Permissão pendente'}
              </p>
            </div>
          </div>

          {pushPermission !== 'granted' ? (
            <button
              onClick={handleRequestPushPermission}
              className="text-[10px] font-extrabold px-2.5 py-1 rounded-lg bg-[#D81B60] text-white hover:bg-[#AD1457] transition-colors shadow-sm"
            >
              Ativar
            </button>
          ) : (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
              Concedida
            </span>
          )}
        </div>
      </div>

      {/* Center Phone Frame */}
      <div className="flex justify-center items-center py-2">
        {/* Smartphone Shell with metallic gold bezel details */}
        <div className="relative w-full max-w-[420px] rounded-[48px] bg-[#061D12] p-4 shadow-2xl border-[6px] border-[#15462D] ring-4 ring-[#D4AF37]/50">
          {/* Top Speaker & Camera Notch */}
          <div className="absolute top-6 left-1/2 -translate-x-1/2 w-32 h-4 bg-[#0D3823] rounded-full flex items-center justify-center gap-2 z-30 shadow-inner">
            <div className="w-2.5 h-2.5 rounded-full bg-[#061D12] border border-[#D4AF37]/30" />
            <div className="w-10 h-1 rounded-full bg-[#061D12]" />
          </div>

          {/* Screen Content Container */}
          <div className="rounded-[36px] bg-[#F8F9FA] text-[#1A2E22] overflow-hidden min-h-[690px] flex flex-col relative border border-slate-200">
            {/* Status Bar */}
            <div className="pt-3.5 px-6 pb-2 flex items-center justify-between text-[11px] font-bold text-[#0D3823] z-20 bg-white/85 backdrop-blur-sm border-b border-slate-100">
              <span>09:41</span>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-slate-500 font-bold">5G</span>
                <div className="w-4 h-2 border border-[#0D3823] rounded-sm p-0.5 flex items-center">
                  <div className="w-full h-full bg-[#0D3823] rounded-[1px]" />
                </div>
              </div>
            </div>

            {/* In-Phone Simulated Push Banner (Notch Dropdown) */}
            {inPhonePushBanner && (
              <div className="absolute top-10 left-3 right-3 z-40 animate-in slide-in-from-top-6 duration-300">
                <div className="p-3 rounded-2xl bg-gradient-to-r from-[#061D12] to-[#0D3823] border-2 border-[#D4AF37] shadow-2xl text-white space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <VillageAzaleiaLogo variant="icon" size="sm" />
                      <span className="text-[10px] font-brand font-black text-[#FFF2B2]">Village Azaleia</span>
                      <span className="text-[9px] px-1 py-0.2 bg-[#D81B60] text-white rounded font-extrabold uppercase">
                        Push
                      </span>
                    </div>
                    <button
                      onClick={() => setInPhonePushBanner(null)}
                      className="text-white/60 hover:text-white p-0.5"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="text-xs font-black text-white">Nova encomenda recebida para sua unidade!</div>
                  <div className="text-[11px] text-white/80 leading-tight font-medium">
                    {inPhonePushBanner.carrier} ({inPhonePushBanner.trackingCode}) disponível na Estante{' '}
                    {inPhonePushBanner.shelfString}.
                  </div>
                </div>
              </div>
            )}

            {/* PWA Header */}
            <div className="px-5 py-3 bg-gradient-to-b from-white to-[#F8F9FA] border-b border-[#D4AF37]/25 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-2.5">
                <VillageAzaleiaLogo variant="icon" size="sm" />
                <div>
                  <div className="font-brand text-[10px] font-black text-[#D81B60] tracking-wider uppercase">
                    Village Azaleia
                  </div>
                  <h1 className="text-sm font-black text-[#0D3823]">
                    Olá, {currentUnit.residentName.split(' ')[0]}
                  </h1>
                  <span className="text-[11px] text-slate-500 font-bold">
                    Bloco {currentUnit.block} • Apto {currentUnit.apartment}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setShowRegistrationModal(true)}
                  title="Editar dados e telefones do morador"
                  className="p-2 rounded-xl bg-white hover:bg-[#FCE4EC] text-[#0D3823] border border-slate-200 shadow-sm transition-colors"
                >
                  <Edit3 className="w-4 h-4 text-[#0D3823]" />
                </button>

                {/* Notification Bell with Badge */}
                <button
                  onClick={() => {
                    setShowNotificationDrawer(!showNotificationDrawer);
                    sound.playScanBeep();
                  }}
                  title="Central de Notificações"
                  className="p-2 rounded-xl bg-white hover:bg-[#FCE4EC] text-[#0D3823] relative border border-slate-200 shadow-sm transition-colors"
                >
                  <BellRing className="w-4 h-4 text-[#D81B60]" />
                  {availablePackages.length > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#D81B60] text-white text-[9px] font-black flex items-center justify-center ring-2 ring-white animate-pulse">
                      {availablePackages.length}
                    </span>
                  )}
                </button>
              </div>
            </div>

            {/* Notification Drawer Modal (inside phone) */}
            {showNotificationDrawer && (
              <div className="absolute inset-x-0 top-20 bottom-14 z-30 bg-white/95 backdrop-blur-md p-4 flex flex-col space-y-3 overflow-y-auto animate-in fade-in">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-[#D81B60]" />
                    <h4 className="text-xs font-black text-[#0D3823]">Central de Notificações</h4>
                  </div>
                  <button
                    onClick={() => setShowNotificationDrawer(false)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-2 flex-1">
                  {myNotifications.length > 0 ? (
                    myNotifications.map((notif) => (
                      <div
                        key={notif.id}
                        className="p-3 rounded-xl bg-[#F8F9FA] border border-slate-200 space-y-1 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-[#D81B60] text-[11px]">{notif.title}</span>
                          <span className="text-[9px] text-slate-400">
                            {new Date(notif.timestamp).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 leading-snug">{notif.body}</p>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-xs">
                      <Bell className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                      Nenhuma notificação anterior registrada para esta unidade.
                    </div>
                  )}
                </div>

                <button
                  onClick={() => setShowNotificationDrawer(false)}
                  className="w-full py-2 rounded-xl bg-[#0D3823] text-white font-bold text-xs"
                >
                  Voltar ao Início
                </button>
              </div>
            )}

            {/* Install PWA & Push Permission Prompt Banner */}
            {!isInstalledPwa && (
              <div className="mx-4 mt-3 p-3 rounded-2xl bg-gradient-to-r from-[#0D3823] to-[#15462D] border border-[#D4AF37]/40 flex items-center justify-between gap-2 shadow-md">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-[#D81B60] text-white shadow-sm">
                    <Download className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">Instalar App Village</div>
                    <div className="text-[10px] text-[#FFF2B2] font-semibold">Receba alertas em tempo real</div>
                  </div>
                </div>
                <button
                  onClick={handleInstallPWA}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#C5A059] hover:from-[#C5A059] hover:to-[#B38F48] text-[#061D12] text-xs font-extrabold transition-all shadow"
                >
                  Instalar
                </button>
              </div>
            )}

            {/* Tab Navigation (Disponíveis vs Histórico vs Canais) */}
            <div className="px-4 mt-3">
              <div className="grid grid-cols-3 p-1 bg-white rounded-xl border border-slate-200 text-[11px] font-bold shadow-sm">
                <button
                  onClick={() => {
                    setActiveScreenTab('disponiveis');
                    sound.playScanBeep();
                  }}
                  className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1 ${
                    activeScreenTab === 'disponiveis'
                      ? 'bg-gradient-to-r from-[#D81B60] to-[#AD1457] text-white shadow-sm font-black'
                      : 'text-slate-500 hover:text-[#0D3823]'
                  }`}
                >
                  <Package className="w-3 h-3" />
                  <span>Para Retirar ({availablePackages.length})</span>
                </button>

                <button
                  onClick={() => {
                    setActiveScreenTab('historico');
                    sound.playScanBeep();
                  }}
                  className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1 ${
                    activeScreenTab === 'historico'
                      ? 'bg-gradient-to-r from-[#D81B60] to-[#AD1457] text-white shadow-sm font-black'
                      : 'text-slate-500 hover:text-[#0D3823]'
                  }`}
                >
                  <Clock className="w-3 h-3" />
                  <span>Histórico ({pickedUpPackages.length})</span>
                </button>

                <button
                  onClick={() => {
                    setActiveScreenTab('notificacoes');
                    sound.playScanBeep();
                  }}
                  className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1 ${
                    activeScreenTab === 'notificacoes'
                      ? 'bg-gradient-to-r from-[#D81B60] to-[#AD1457] text-white shadow-sm font-black'
                      : 'text-slate-500 hover:text-[#0D3823]'
                  }`}
                >
                  <Radio className="w-3 h-3" />
                  <span>Canais</span>
                </button>
              </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3.5">
              {activeScreenTab === 'disponiveis' && (
                <>
                  {availablePackages.length > 0 ? (
                    availablePackages.map((pkg) => {
                      const cfg = CARRIER_CONFIG[pkg.carrier] || { icon: '📦', color: '#D81B60' };
                      return (
                        <div
                          key={pkg.id}
                          className="bg-white rounded-2xl border-2 border-[#D4AF37]/40 p-4 space-y-3.5 shadow-md relative overflow-hidden ring-1 ring-[#D81B60]/20"
                        >
                          {/* Top Status alert */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="px-2.5 py-1 rounded-md text-[11px] font-black bg-[#FCE4EC] text-[#AD1457] border border-[#F48FB1] flex items-center gap-1.5">
                                <span className="w-2 h-2 rounded-full bg-[#D81B60] animate-ping" />
                                <span>Disponível na Portaria</span>
                              </span>
                            </div>
                            <span className="text-[11px] font-extrabold text-[#0D3823] flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                              <span>{cfg.icon}</span>
                              <span>{pkg.carrier}</span>
                            </span>
                          </div>

                          {/* Parcel Photo & Storage Shelf Highlight */}
                          <div className="flex gap-3 items-center">
                            <img
                              src={pkg.photoUrl}
                              alt="Caixa"
                              className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0 shadow-sm"
                              referrerPolicy="no-referrer"
                            />
                            <div className="space-y-1">
                              <div className="text-xs font-mono text-[#0D3823] font-bold">{pkg.trackingCode}</div>
                              <div className="text-[11px] text-slate-500 flex items-center gap-1 font-medium">
                                <Clock className="w-3 h-3 text-slate-400" />
                                <span>
                                  Chegou às{' '}
                                  {new Date(pkg.receivedAt).toLocaleTimeString('pt-BR', {
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })}
                                </span>
                              </div>

                              {/* Physical Shelf location */}
                              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#E8F5E9] border border-[#A5D6A7] text-[11px]">
                                <MapPin className="w-3 h-3 text-[#0D3823]" />
                                <span className="text-slate-600">Guarda:</span>
                                <strong className="text-[#0D3823] font-black">
                                  Estante {pkg.shelf.shelf} • Prat. {pkg.shelf.level}
                                </strong>
                              </div>
                            </div>
                          </div>

                          {/* QR CODE CARD IN HIGHLIGHT */}
                          <div className="bg-[#061D12] text-white rounded-2xl p-4 border-2 border-[#D4AF37]/60 flex flex-col items-center justify-center text-center space-y-2 shadow-inner">
                            <span className="text-[11px] font-bold text-[#FFF2B2] flex items-center gap-1">
                              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                              <span>Apresente na portaria para retirada:</span>
                            </span>

                            <div
                              className="cursor-pointer group relative bg-white p-2 rounded-xl border-2 border-[#D4AF37] shadow-lg"
                              onClick={() => setFullscreenQrPackage(pkg)}
                            >
                              <QRCodeDisplay value={pkg.qrToken} size={135} />
                              <div className="absolute inset-0 bg-[#061D12]/80 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-[11px] font-bold gap-1">
                                <Maximize2 className="w-4 h-4 text-[#FFF2B2]" />
                                <span>Ampliar</span>
                              </div>
                            </div>

                            <span className="text-[10px] font-mono text-[#FFF2B2] bg-[#0D3823] px-2.5 py-0.5 rounded border border-[#D4AF37]/30">
                              {pkg.qrToken}
                            </span>
                          </div>

                          {/* Button to expand QR Code */}
                          <button
                            onClick={() => setFullscreenQrPackage(pkg)}
                            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#D81B60] to-[#AD1457] hover:from-[#AD1457] hover:to-[#880E4F] text-white text-xs font-black flex items-center justify-center gap-1.5 transition-all shadow-md shadow-[#D81B60]/20"
                          >
                            <Maximize2 className="w-3.5 h-3.5 text-[#FFF2B2]" />
                            <span>Abrir QR Code em Tela Cheia</span>
                          </button>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-12 space-y-3 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                      <div className="w-14 h-14 rounded-2xl bg-[#E8F5E9] text-[#0D3823] mx-auto flex items-center justify-center border border-[#A5D6A7]">
                        <CheckCircle2 className="w-8 h-8 text-[#0D3823]" />
                      </div>
                      <h4 className="text-sm font-black text-[#0D3823]">Tudo em dia por aqui!</h4>
                      <p className="text-xs text-slate-500">
                        Você não possui nenhuma encomenda aguardando retirada na portaria neste momento.
                      </p>
                      <button
                        onClick={handleTestMultichannel}
                        className="mt-2 px-3 py-1.5 rounded-xl bg-[#FCE4EC] border border-[#F48FB1] text-[#D81B60] text-xs font-bold inline-flex items-center gap-1.5"
                      >
                        <Send className="w-3 h-3" />
                        <span>Testar Disparo Multicanal</span>
                      </button>
                    </div>
                  )}
                </>
              )}

              {activeScreenTab === 'historico' && (
                <div className="space-y-3">
                  {pickedUpPackages.length > 0 ? (
                    pickedUpPackages.map((pkg) => (
                      <div
                        key={pkg.id}
                        onClick={() => setSelectedReceipt(pkg)}
                        className="p-3.5 rounded-xl bg-white hover:bg-[#FCE4EC]/30 border border-slate-200 hover:border-[#D81B60]/40 transition-colors cursor-pointer flex items-center justify-between gap-3 text-xs shadow-sm"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-[#E8F5E9] text-[#0D3823] border border-[#A5D6A7] flex items-center justify-center shrink-0">
                            <Check className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="font-black text-[#0D3823]">{pkg.carrier}</div>
                            <div className="text-[11px] text-slate-500 font-mono">{pkg.trackingCode}</div>
                            <div className="text-[10px] text-slate-600 mt-0.5">
                              Retirado por: <strong>{pkg.pickedUpBy || pkg.residentName}</strong>
                            </div>
                          </div>
                        </div>

                        <div className="text-right flex items-center gap-1.5 text-[#D81B60] font-bold">
                          <span className="text-[11px]">Ver Recibo</span>
                          <ChevronRight className="w-4 h-4" />
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-10 text-slate-500 text-xs bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                      Nenhuma retirada registrada ainda no histórico deste apartamento.
                    </div>
                  )}
                </div>
              )}

              {/* Notification Channels Tab */}
              {activeScreenTab === 'notificacoes' && (
                <div className="space-y-3 text-xs">
                  {/* Family WhatsApp Numbers */}
                  <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3 shadow-sm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-4 h-4 text-emerald-600" />
                        <h4 className="font-black text-[#0D3823]">WhatsApp da Família</h4>
                      </div>
                      <button
                        onClick={() => setShowRegistrationModal(true)}
                        className="text-[10px] font-bold text-[#D81B60] hover:underline"
                      >
                        Gerenciar
                      </button>
                    </div>

                    <div className="space-y-1.5">
                      {(currentUnit.residentPhones && currentUnit.residentPhones.length > 0
                        ? currentUnit.residentPhones
                        : [
                            {
                              id: 'p1',
                              label: 'Titular',
                              number: currentUnit.residentPhone || '(11) 98765-4321',
                              isWhatsapp: true
                            }
                          ]
                      ).map((p, i) => (
                        <div
                          key={p.id || i}
                          className="p-2 rounded-xl bg-[#F8F9FA] border border-slate-100 flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2">
                            <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[9px] font-extrabold">
                              {p.label}
                            </span>
                            <span className="font-mono text-slate-700 font-bold">{p.number}</span>
                          </div>
                          <span className="text-[10px] text-emerald-600 font-bold">✓ Evolution API</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Email & Web Push Status */}
                  <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-2.5 shadow-sm">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-[#D81B60]" />
                      <h4 className="font-black text-[#0D3823]">E-mail & Web Push</h4>
                    </div>

                    <div className="p-2.5 rounded-xl bg-[#F8F9FA] border border-slate-100 space-y-1">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="text-slate-500">E-mail:</span>
                        <span className="font-bold text-[#0D3823]">{currentUnit.residentEmail}</span>
                      </div>
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="text-slate-500">Notificações Push:</span>
                        <span
                          className={`font-bold ${
                            pushPermission === 'granted' ? 'text-emerald-600' : 'text-amber-600'
                          }`}
                        >
                          {pushPermission === 'granted' ? 'Ativadas' : 'Pendente autorização'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Dispatch Report (if triggered) */}
                  {lastDispatchReport && (
                    <div className="bg-[#061D12] text-white rounded-2xl border border-[#D4AF37] p-4 space-y-2.5 shadow-md">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
                        <span className="font-bold text-xs text-[#FFF2B2]">Último Relatório Multicanal</span>
                      </div>
                      <div className="text-[10px] font-mono space-y-1 text-white/90">
                        <div>
                          WhatsApp Disparados: <strong>{lastDispatchReport.whatsappDispatches.length}</strong>
                        </div>
                        <div>
                          Resend E-mail: <strong>{lastDispatchReport.emailDispatch.status}</strong>
                        </div>
                        <div>
                          Web Push PWA: <strong>{lastDispatchReport.webPushDispatch.status}</strong>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* PWA Bottom Navigation Bar */}
            <div className="px-6 py-3 bg-white border-t border-slate-200 flex items-center justify-around text-[10px] text-slate-500 shadow-sm">
              <button
                onClick={() => setActiveScreenTab('disponiveis')}
                className={`flex flex-col items-center gap-1 ${
                  activeScreenTab === 'disponiveis' ? 'text-[#D81B60] font-black' : 'hover:text-[#0D3823]'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>Encomendas</span>
              </button>

              <button
                onClick={() => setActiveScreenTab('historico')}
                className={`flex flex-col items-center gap-1 ${
                  activeScreenTab === 'historico' ? 'text-[#D81B60] font-black' : 'hover:text-[#0D3823]'
                }`}
              >
                <Clock className="w-4 h-4" />
                <span>Histórico</span>
              </button>

              <button
                onClick={() => setActiveScreenTab('notificacoes')}
                className={`flex flex-col items-center gap-1 ${
                  activeScreenTab === 'notificacoes' ? 'text-[#D81B60] font-black' : 'hover:text-[#0D3823]'
                }`}
              >
                <Radio className="w-4 h-4" />
                <span>Canais</span>
              </button>

              <button
                onClick={() => setShowRegistrationModal(true)}
                className="flex flex-col items-center gap-1 hover:text-[#0D3823]"
              >
                <User className="w-4 h-4" />
                <span>Perfil</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* AUTO-CADASTRO & TELEFONES MODAL */}
      <MoradorRegistrationModal
        isOpen={showRegistrationModal}
        onClose={() => setShowRegistrationModal(false)}
        units={units}
        currentUnit={currentUnit}
        onSaveUnit={handleSaveResidentProfile}
        onShowToast={onShowToast}
      />

      {/* FULLSCREEN QR CODE MODAL */}
      {fullscreenQrPackage && (
        <div className="fixed inset-0 z-50 bg-[#061D12]/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-2 border-[#D4AF37] p-6 max-w-sm w-full shadow-2xl text-center space-y-4 text-[#1A2E22] animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="text-left">
                <span className="text-[11px] font-black text-[#D81B60] uppercase tracking-wider">
                  Apresente na Portaria
                </span>
                <h4 className="text-base font-black text-[#0D3823]">QR Code de Retirada</h4>
              </div>
              <button
                onClick={() => setFullscreenQrPackage(null)}
                className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-2 flex justify-center bg-[#F8F9FA] rounded-2xl border border-slate-200 p-3 shadow-inner">
              <QRCodeDisplay value={fullscreenQrPackage.qrToken} size={220} />
            </div>

            <div className="space-y-1 text-xs">
              <div className="font-black text-[#0D3823] text-sm">
                Bloco {fullscreenQrPackage.block} — Apartamento {fullscreenQrPackage.apartment}
              </div>
              <div className="text-slate-500 font-mono text-[11px]">{fullscreenQrPackage.trackingCode}</div>
              <div className="text-[#0D3823] font-black pt-1 bg-[#E8F5E9] py-1 rounded-lg border border-[#A5D6A7]">
                Local: Estante {fullscreenQrPackage.shelf.shelf} • Prateleira {fullscreenQrPackage.shelf.level}
              </div>
            </div>

            <button
              onClick={() => {
                setFullscreenQrPackage(null);
                sound.playScanBeep();
              }}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#D81B60] to-[#AD1457] hover:from-[#AD1457] hover:to-[#880E4F] text-white font-black text-xs shadow-md"
            >
              Fechar QR Code
            </button>
          </div>
        </div>
      )}

      {/* DIGITAL DELIVERY RECEIPT MODAL */}
      <DeliveryReceiptModal
        isOpen={Boolean(selectedReceipt)}
        onClose={() => setSelectedReceipt(null)}
        pkg={selectedReceipt}
        unit={currentUnit}
        onShowToast={onShowToast}
      />
    </div>
  );
};

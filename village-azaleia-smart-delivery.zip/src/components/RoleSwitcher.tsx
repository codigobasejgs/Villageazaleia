import React from 'react';
import { AppRole } from '../types';
import { Shield, Smartphone, Box, BarChart3, Volume2, VolumeX, RotateCcw } from 'lucide-react';
import { sound } from '../utils/audio';
import { VillageAzaleiaLogo } from './VillageAzaleiaLogo';

interface RoleSwitcherProps {
  currentRole: AppRole;
  onRoleChange: (role: AppRole) => void;
  pendingCount: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onResetData: () => void;
}

export const RoleSwitcher: React.FC<RoleSwitcherProps> = ({
  currentRole,
  onRoleChange,
  pendingCount,
  soundEnabled,
  onToggleSound,
  onResetData
}) => {
  const roles: { id: AppRole; label: string; icon: React.ReactNode; badge?: number; description: string }[] = [
    {
      id: 'portaria',
      label: 'Portaria / Recepção',
      icon: <Shield className="w-4 h-4" />,
      badge: pendingCount,
      description: 'Recepção e Checkout Rápido'
    },
    {
      id: 'morador',
      label: 'PWA Morador',
      icon: <Smartphone className="w-4 h-4" />,
      description: 'App Mobile, QR Code e Avisos'
    },
    {
      id: 'totem',
      label: 'Totem Entregador',
      icon: <Box className="w-4 h-4" />,
      description: 'Autoatendimento Kiosk'
    },
    {
      id: 'sindico',
      label: 'Painel Síndico',
      icon: <BarChart3 className="w-4 h-4" />,
      description: 'Métricas, Ocupação e Auditoria'
    }
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#061D12]/95 backdrop-blur-md border-b border-[#D4AF37]/30 shadow-xl">
      {/* Top micro-bar with official identity */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs text-emerald-100/70 border-b border-[#0D3823]/90">
        <div className="flex items-center gap-3">
          <VillageAzaleiaLogo variant="horizontal" size="sm" />
          <div className="hidden lg:flex items-center gap-2 pl-3 border-l border-[#D4AF37]/30">
            <span className="px-2.5 py-0.5 rounded-full bg-[#0D3823] text-[11px] text-[#FFF2B2] border border-[#D4AF37]/30 font-medium">
              360 Unidades • 12 Blocos • Portaria Central
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Silenciar efeitos sonoros' : 'Ativar efeitos sonoros'}
            className="px-2.5 py-1.5 rounded-xl bg-[#0D3823] hover:bg-[#15462D] text-emerald-100 border border-[#D4AF37]/20 transition-all flex items-center gap-1.5 text-xs shadow-sm hover:border-[#D4AF37]/50"
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-[#D4AF37]" /> : <VolumeX className="w-3.5 h-3.5 text-emerald-300/50" />}
            <span className="hidden sm:inline text-[11px] font-medium">{soundEnabled ? 'Som Ativo' : 'Mudo'}</span>
          </button>

          <button
            onClick={() => {
              if (window.confirm('Deseja restaurar as encomendas e configurações de demonstração iniciais?')) {
                onResetData();
                sound.playSuccess();
              }
            }}
            title="Restaurar dados de demonstração"
            className="px-2.5 py-1.5 rounded-xl bg-[#0D3823] hover:bg-[#15462D] text-emerald-100 hover:text-white border border-[#D4AF37]/20 hover:border-[#D4AF37]/60 transition-all flex items-center gap-1.5 text-[11px] shadow-sm"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="hidden sm:inline font-medium">Resetar Dados</span>
          </button>
        </div>
      </div>

      {/* Role Navigation Bar with Brand Accents */}
      <div className="max-w-7xl mx-auto px-4 py-2">
        <div className="flex items-center justify-start md:justify-center overflow-x-auto no-scrollbar gap-2 py-0.5">
          {roles.map((role) => {
            const isActive = currentRole === role.id;
            return (
              <button
                key={role.id}
                onClick={() => {
                  onRoleChange(role.id);
                  sound.playScanBeep();
                }}
                className={`group relative flex items-center gap-2 px-3.5 py-2 rounded-xl font-medium text-xs sm:text-sm transition-all duration-200 whitespace-nowrap ${
                  isActive
                    ? 'bg-gradient-to-r from-[#D81B60] via-[#E91E63] to-[#AD1457] text-white shadow-lg shadow-[#D81B60]/30 ring-1 ring-[#FFF2B2]/60'
                    : 'bg-[#0D3823]/80 hover:bg-[#0D3823] text-emerald-100/90 hover:text-white border border-[#D4AF37]/25 hover:border-[#D4AF37]/50'
                }`}
              >
                <span className={`${isActive ? 'text-white' : 'text-[#D4AF37] group-hover:scale-110'} transition-transform`}>
                  {role.icon}
                </span>
                <span className="font-semibold tracking-wide">{role.label}</span>
                {typeof role.badge === 'number' && role.badge > 0 && (
                  <span
                    className={`ml-0.5 px-1.5 py-0.2 text-[11px] font-bold rounded-full shadow-sm ${
                      isActive
                        ? 'bg-white text-[#AD1457]'
                        : 'bg-[#D81B60] text-white border border-[#FFF2B2]/40'
                    }`}
                  >
                    {role.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
